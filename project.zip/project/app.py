from flask import Flask, render_template, request, redirect, url_for, session
import boto3

app = Flask(__name__)
app.secret_key = 'your_secret_key'

# Replace 'your_access_key' and 'your_secret_key' with your AWS credentials
dynamodb = boto3.resource('dynamodb', region_name='your_region', aws_access_key_id='your_access_key',
                          aws_secret_access_key='your_secret_key')
travel_table = dynamodb.Table('travel')
user_table = dynamodb.Table('users')


# Add a new route for the edit_profile page
@app.route('/edit_profile')
def edit_profile():
    if 'user' in session:
        user = session['user']
        return render_template('edit_profile.html', user=user)
    else:
        return redirect(url_for('home'))


# Add a new route for updating the profile information
@app.route('/update_profile', methods=['POST'])
def update_profile():
    if 'user' in session:
        # Implement your profile update logic here
        session['user'] = request.form['username']
        # For simplicity, you may want to redirect to the profile page
        return redirect(url_for('profile'))
    else:
        return redirect(url_for('home'))


@app.route('/')
def home():
    return render_template('home.html')


@app.route('/login', methods=['POST'])
def login():
    if request.method == "POST":
        session["username"] = username = request.form["username"]
        password = request.form["password"]
        # checks if exists and if true session is logged in
        if db_check_creds(username, password):
            session["logged_in"] = True
            return redirect(url_for("client"))
        else:
            return redirect(url_for("home"))


@app.route('/logout')
def logout():
    if request.method == 'POST':
        session['logged_in'] = False
        session.pop('username', None)
        return redirect(url_for('home'))


@app.route('/profile')
def profile():
    if 'user' in session:
        user = session['user']
        items = get_user_items(user)
        return render_template('profile.html', user=user, items=items)
    else:
        return redirect(url_for('home'))


@app.route('/add_travel', methods=['POST'])
def add_travel():
    if 'user' in session:
        user = session['user']
        data = {
            'Travel_Id': request.form['date'],
            'Name': user,
            'City': request.form['city'],
            'State': request.form['state'],
            'Country': request.form['country'],
            'Trip_Rating': int(request.form['rating']),
            'Comments': request.form['comments'],
            'Image URL': request.form['image_url']
            # Add 'Image_URL' if you want to store it in the database
        }

        travel_table.put_item(Item=data)
        return redirect(url_for('profile'))
    else:
        return redirect(url_for('home'))


def get_all_items():
    response = travel_table.scan()
    return response.get('Items', [])


def get_user_items(user):
    response = user_table.scan(FilterExpression=boto3.dynamodb.conditions.Attr('Name').eq(user))
    return response.get('Items', [])


def gallery():
    # Replace the following logic with your actual data retrieval from DynamoDB
    response = travel_table.scan()
    entries = response.get('Items', [])

    return render_template('gallery.html', entries=entries)


if __name__ == '__main__':
    app.run(debug=True)
